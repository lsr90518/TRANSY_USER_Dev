//
//  NavController.h
//  CuteAnimals
//
//  Copyright 2012 Google, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavController :
    UINavigationController<UINavigationControllerDelegate>

@end
